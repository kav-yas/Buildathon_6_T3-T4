package com.example.student_api.controller;

import com.example.student_api.model.Student;
import com.example.student_api.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class StudentController {

    @Autowired
    private StudentRepository studentRepository;

    // Helper method to calculate grades based on marks and max marks
    private String calculateGrade(int marks, int maxMarks) {
        double percentage = (marks / (double) maxMarks) * 100;
        if (percentage >= 90) return "S";  // Grade S
        if (percentage >= 85) return "A+"; // Grade A+
        if (percentage >= 80) return "A";  // Grade A
        if (percentage >= 75) return "B+"; // Grade B+
        if (percentage >= 70) return "B";  // Grade B
        if (percentage >= 65) return "C+"; // Grade C+
        if (percentage >= 60) return "C";  // Grade C
        if (percentage >= 55) return "D+"; // Grade D+
        if (percentage >= 50) return "D";  // Grade D
        return "F";  // Failed (Grade F)
    }

    @PostMapping("/studentEntry")
    public ResponseEntity<Map<String, String>> studentEntry(@RequestBody Student student) {
        // Calculate grades for each subject
        student.setGrade1(calculateGrade(student.getMarks1(), student.getMaxMarks1()));
        student.setGrade2(calculateGrade(student.getMarks2(), student.getMaxMarks2()));
        student.setGrade3(calculateGrade(student.getMarks3(), student.getMaxMarks3()));
        student.setGrade4(calculateGrade(student.getMarks4(), student.getMaxMarks4()));
        student.setGrade5(calculateGrade(student.getMarks5(), student.getMaxMarks5()));
        student.setGrade6(calculateGrade(student.getMarks6(), student.getMaxMarks6()));

        // Set qualification status based on grades
        if ("F".equals(student.getGrade1()) || "F".equals(student.getGrade2()) ||
                "F".equals(student.getGrade3()) || "F".equals(student.getGrade4()) ||
                "F".equals(student.getGrade5()) || "F".equals(student.getGrade6())) {
            student.setQualificationStatus("Failed");
        } else {
            student.setQualificationStatus("Passed");
        }

        // Save student to the database
        studentRepository.save(student);
        Map<String, String> response = new HashMap<>();
        response.put("Status", "Student Added Successfully");
        return ResponseEntity.ok(response);
    }

    @GetMapping("/viewStudents")
    public ResponseEntity<List<Student>> viewStudents() {
        List<Student> students = studentRepository.findAll();
        return ResponseEntity.ok(students);
    }
}
