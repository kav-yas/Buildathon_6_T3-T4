package com.example.student_api.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String rollNumber;
    private String department;

    // Subject names
    private String subject1, subject2, subject3, subject4, subject5, subject6;

    // Marks for each subject
    private int marks1, marks2, marks3, marks4, marks5, marks6;

    // Max Marks for each subject
    private int maxMarks1, maxMarks2, maxMarks3, maxMarks4, maxMarks5, maxMarks6;

    // Grades for each subject
    private String grade1, grade2, grade3, grade4, grade5, grade6;

    // Final qualification status (Passed / Failed)
    private String qualificationStatus;

    // Getters and Setters (You can generate these using your IDE or manually)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRollNumber() {
        return rollNumber;
    }

    public void setRollNumber(String rollNumber) {
        this.rollNumber = rollNumber;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getSubject1() {
        return subject1;
    }

    public void setSubject1(String subject1) {
        this.subject1 = subject1;
    }

    public String getSubject2() {
        return subject2;
    }

    public void setSubject2(String subject2) {
        this.subject2 = subject2;
    }

    public String getSubject3() {
        return subject3;
    }

    public void setSubject3(String subject3) {
        this.subject3 = subject3;
    }

    public String getSubject4() {
        return subject4;
    }

    public void setSubject4(String subject4) {
        this.subject4 = subject4;
    }

    public String getSubject5() {
        return subject5;
    }

    public void setSubject5(String subject5) {
        this.subject5 = subject5;
    }

    public String getSubject6() {
        return subject6;
    }

    public void setSubject6(String subject6) {
        this.subject6 = subject6;
    }

    public int getMarks1() {
        return marks1;
    }

    public void setMarks1(int marks1) {
        this.marks1 = marks1;
    }

    public int getMarks2() {
        return marks2;
    }

    public void setMarks2(int marks2) {
        this.marks2 = marks2;
    }

    public int getMarks3() {
        return marks3;
    }

    public void setMarks3(int marks3) {
        this.marks3 = marks3;
    }

    public int getMarks4() {
        return marks4;
    }

    public void setMarks4(int marks4) {
        this.marks4 = marks4;
    }

    public int getMarks5() {
        return marks5;
    }

    public void setMarks5(int marks5) {
        this.marks5 = marks5;
    }

    public int getMarks6() {
        return marks6;
    }

    public void setMarks6(int marks6) {
        this.marks6 = marks6;
    }

    public int getMaxMarks1() {
        return maxMarks1;
    }

    public void setMaxMarks1(int maxMarks1) {
        this.maxMarks1 = maxMarks1;
    }

    public int getMaxMarks2() {
        return maxMarks2;
    }

    public void setMaxMarks2(int maxMarks2) {
        this.maxMarks2 = maxMarks2;
    }

    public int getMaxMarks3() {
        return maxMarks3;
    }

    public void setMaxMarks3(int maxMarks3) {
        this.maxMarks3 = maxMarks3;
    }

    public int getMaxMarks4() {
        return maxMarks4;
    }

    public void setMaxMarks4(int maxMarks4) {
        this.maxMarks4 = maxMarks4;
    }

    public int getMaxMarks5() {
        return maxMarks5;
    }

    public void setMaxMarks5(int maxMarks5) {
        this.maxMarks5 = maxMarks5;
    }

    public int getMaxMarks6() {
        return maxMarks6;
    }

    public void setMaxMarks6(int maxMarks6) {
        this.maxMarks6 = maxMarks6;
    }

    public String getGrade1() {
        return grade1;
    }

    public void setGrade1(String grade1) {
        this.grade1 = grade1;
    }

    public String getGrade2() {
        return grade2;
    }

    public void setGrade2(String grade2) {
        this.grade2 = grade2;
    }

    public String getGrade3() {
        return grade3;
    }

    public void setGrade3(String grade3) {
        this.grade3 = grade3;
    }

    public String getGrade4() {
        return grade4;
    }

    public void setGrade4(String grade4) {
        this.grade4 = grade4;
    }

    public String getGrade5() {
        return grade5;
    }

    public void setGrade5(String grade5) {
        this.grade5 = grade5;
    }

    public String getGrade6() {
        return grade6;
    }

    public void setGrade6(String grade6) {
        this.grade6 = grade6;
    }

    public String getQualificationStatus() {
        return qualificationStatus;
    }

    public void setQualificationStatus(String qualificationStatus) {
        this.qualificationStatus = qualificationStatus;
    }
}
