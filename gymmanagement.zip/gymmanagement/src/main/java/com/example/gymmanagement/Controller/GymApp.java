package com.example.gymmanagement.Controller;

import com.example.gymmanagement.Models.Gyms;
import com.example.gymmanagement.Repository.GymRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class GymApp {
    @Autowired
    private GymRepository gymRepository;
    @Transactional
    @PostMapping("/gymEntry")
    public ResponseEntity<Map<String,String>>gymEntry(@RequestBody Gyms gym){
        Gyms gymObj = gymRepository.save(gym);
        Map<String,String> response = new HashMap<>();
        response.put("Status","Member Added");
        return ResponseEntity.ok(response);
    }
    @GetMapping("/viewMember")
    public ResponseEntity<List<Gyms>>gymList(){
        List<Gyms> gym = gymRepository.findAll();
        return ResponseEntity.ok(gym);
    }
}
