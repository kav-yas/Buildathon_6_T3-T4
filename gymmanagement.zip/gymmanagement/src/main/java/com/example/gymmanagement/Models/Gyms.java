package com.example.gymmanagement.Models;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Entity;

@Entity
public class Gyms {
    @JsonProperty("memberid")
    private String memberid;

    @JsonProperty("name")
    private String name;

    @JsonProperty("membershiptype")
    private String membershiptype;

    @JsonProperty("activestatus")
    private String activestatus;

    @JsonProperty("workoutplan")
    private String workoutplan;

    public Gyms() {
    }

    public String getMemberid() {
        return memberid;
    }

    public String getName() {
        return name;
    }

    public String getMembershiptype() {
        return membershiptype;
    }

    public String getActivestatus() {
        return activestatus;
    }

    public String getWorkoutplan() {
        return workoutplan;
    }

    public void setMemberid(String memberid) {
        this.memberid = memberid;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMembershiptype(String membershiptype) {
        this.membershiptype = membershiptype;
    }

    public void setActivestatus(String activestatus) {
        this.activestatus = activestatus;
    }

    public void setWorkoutplan(String workoutplan) {
        this.workoutplan = workoutplan;
    }
}
