package com.example.gymmanagement.Repository;

import com.example.gymmanagement.Models.Gyms;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GymRepository  extends JpaRepository<Gyms,Long> {
}
